//Erik Ford
//CSCI 465
//Compiler Project
//last updated 11-11-19

/***********************************************************
 * @author Erik Ford
 * TypeDirectory defines and implements a lookup table that
   contains all variables, subroutines, and their types
 ***********************************************************/
public class TypeDirectory 
{
   
}
